<?php 
if(empty($msg)){
    $display="display:none;";
}else{
    $display="display:block;";
}
?>