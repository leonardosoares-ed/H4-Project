<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title><?php echo $page;?></title>
<link href="https://fonts.googleapis.com/css?family=IM+Fell+French+Canon+SC" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
