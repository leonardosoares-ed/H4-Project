<?php
include("../includes/globais.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Relatórios</title>
<link href="https://fonts.googleapis.com/css?family=IM+Fell+French+Canon+SC" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/style.css"/>
</head>
<body>
<div id="relatorio"><a href="../index.php" title="Home">Home&raquo;</a></div>
<div id="txt"><a href="../txt.php" title="Home">TXT&raquo;</a></div>
<div id="relatoriodata">
        <img src="../views/graficoestatico.php">
</div>
</body>
</html>
