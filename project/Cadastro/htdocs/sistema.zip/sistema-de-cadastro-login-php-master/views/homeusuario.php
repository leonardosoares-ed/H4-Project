<?php
$page="Painel Do Usuário";
include("views/header.php");
?>
<body>
<h1>teste</h1>

</body>
</html>