<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Estátistica ADM</title>
<link href="https://fonts.googleapis.com/css?family=IM+Fell+French+Canon+SC" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/style.css"/>
</head>
<body>

	<div id="cadastrar"><a href="../index.php?acao=logout" title="Fazer logout"> Logout &raquo;</a></div>
		<div class="message" ></div>
		<div class="grafico">
		<fieldset>
           <img src="../controllers/criarG.php" alt="grafico teste" title="grafico teste"/>
        </fieldset>
		<!--acomodar-->
		</div>
		<!--login-->

</body>
</html>
